# CMDO Discord Bot

## Overview
A fully-featured Discord bot with moderation, fun commands, music queue system, and a web dashboard.

## Current Status
- ✅ Dashboard: Working (login at https://3fb96250-9255-44fb-ac52-29294ec584d8-00-1va3cx7vlytw3.kirk.replit.dev)
- ✅ Queue System: Working (`,play`, `,queue`, `,skip`, `,nowplaying`, `,clearqueue`)
- ❌ Voice Audio: Requires external VPS (Replit infrastructure doesn't support Discord voice streaming)

## Music Queue Commands
- `,play <song>` - Add YouTube song to queue
- `,queue` - View all queued songs
- `,nowplaying` (`,np`) - See current song
- `,skip` - Skip to next song
- `,clearqueue` (`,cq`) - Clear entire queue

## Deploying to Railway.app (For Voice Audio to Work)

Since Replit's infrastructure blocks Discord voice connections, you need to deploy to Railway.app where voice will actually work.

### Railway.app Deployment Steps:

**1. Connect your GitHub repository:**
- Go to https://railway.app
- Click "New Project"
- Select "Deploy from GitHub"
- Connect your GitHub account
- Select this repository

**2. Set environment variables on Railway:**
- Go to your Railway project dashboard
- Click "Variables"
- Add these variables:
  - `TOKEN` = Your Discord bot token
  - `OPENAI_API_KEY` = (optional) For AI features
  - `SESSION_SECRET` = Any random string (for dashboard security)

**3. Deploy:**
- Railway will automatically detect `package.json` and deploy
- Your bot will start running with `npm start` (node index.js)
- The queue system AND voice audio will work!

**4. Keep it running 24/7:**
- Railway keeps your bot online continuously
- $5/month for always-on hosting is typical

### Why This Works:
- Railway has proper internet infrastructure for Discord voice streaming
- Replit's network specifically blocks Discord voice connections
- The exact same code works on Railway with full audio playback
- Voice commands like `,play` will actually stream audio

### Quick Reference:
- **Bot Token:** Get from Discord Developer Portal
- **Hosting Cost:** ~$5/month on Railway
- **Setup Time:** ~5 minutes

## Architecture
- `index.js` - Main bot file with Discord client, Express dashboard
- `commands/` - Command handlers organized by category
- `data/` - JSON storage for messages, roles, queue data
- `views/` - EJS templates for web dashboard
- `public/` - Static files for dashboard

## Features Implemented
- ✅ Bot dashboard with stats
- ✅ Music queue system (text-based, YouTube integration)
- ✅ Moderation commands (ban, kick, warn, etc.)
- ✅ Fun commands (jokes, trivia, 8ball, etc.)
- ✅ Utility commands (avatar, userinfo, etc.)
- ✅ Auto-roles system
- ✅ Invite tracking
- ✅ Message logging

## Recent Changes (Nov 27, 2025)
- Fixed queue system to work reliably on Replit
- Updated music commands to use YouTube search (ytsearch:)
- Added dashboard website
- Removed broken voice playback attempts (Replit limitation)
