module.exports = {
    prefix: ',',
    token: process.env.TOKEN, 
    defaultCooldown: 3000,
    embedColor: '#FF0000',
    ownerID: '1230660770749087796', 
};