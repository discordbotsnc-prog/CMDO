const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'info',
    description: 'Get detailed information about commands',
    usage: ',info [command name]',
    category: 'info',
    cooldown: 3,
    execute(message, args) {
        const { commands } = message.client;

        // If no command specified, show command categories
        if (!args.length) {
            const categories = [...new Set(commands.map(cmd => cmd.category))];
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('📖 Command Categories')
                .setDescription('Use `,info <command>` to get detailed information about a specific command')
                .addFields(
                    categories.map(category => ({
                        name: category.charAt(0).toUpperCase() + category.slice(1),
                        value: commands
                            .filter(cmd => cmd.category === category)
                            .map(cmd => `\`${cmd.name}\``)
                            .join(', ')
                    }))
                )
                .setFooter({ text: `Requested by ${message.author.tag}` });

            return message.channel.send({ embeds: [embed] });
        }

        const commandName = args[0].toLowerCase();
        const command = commands.get(commandName) ||
            commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

        if (!command) {
            return message.reply('That\'s not a valid command! Use `,info` to see all categories and commands.');
        }

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`Command: ${command.name}`)
            .addFields(
                { name: '📝 Description', value: command.description || 'No description available' },
                { name: '🔧 Usage', value: command.usage || 'No usage specified' },
                { name: '📁 Category', value: command.category || 'No category specified' },
                { name: '⏰ Cooldown', value: `${command.cooldown || 3} seconds` }
            );

        if (command.aliases) {
            embed.addFields({ name: '🔄 Aliases', value: command.aliases.join(', ') });
        }

        if (command.permissions) {
            embed.addFields({ 
                name: '🔒 Required Permissions', 
                value: command.permissions
                    .map(perm => perm.toString().replace(/_/g, ' ').toLowerCase())
                    .join(', ')
            });
        }

        message.channel.send({ embeds: [embed] });
    },
};