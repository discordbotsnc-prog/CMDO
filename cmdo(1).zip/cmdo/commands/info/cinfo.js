
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'cinfo',
    description: 'Display information about cmdo bot',
    usage: ',cinfo',
    category: 'info',
    cooldown: 3,
    execute(message, args) {
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('About cmdo')
            .setDescription('**Hey i am cmdo that has alot of commands and alot more the prefix for cmdo is , and this bot was created by Gwey and Flex if you need more help join the offical server https://discord.gg/vn5jpeuTnY**')
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};
