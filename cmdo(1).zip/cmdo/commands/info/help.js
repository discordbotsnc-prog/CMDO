
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Shows all available commands',
    usage: ',help',
    category: 'info',
    cooldown: 3,
    execute(message, args) {
        const { commands } = message.client;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📚 Command List')
            .setDescription('Here are all available commands:')
            .addFields(
                {
                    name: '🛡️ Moderation',
                    value: commands.filter(cmd => cmd.category === 'moderation')
                        .map(cmd => `\`,${cmd.name}\``)
                        .join(' '),
                    inline: false
                },
                {
                    name: '🎮 Fun',
                    value: commands.filter(cmd => cmd.category === 'fun')
                        .map(cmd => `\`,${cmd.name}\``)
                        .join(' '),
                    inline: false
                },
                {
                    name: '🔧 Utility',
                    value: commands.filter(cmd => cmd.category === 'utility')
                        .map(cmd => `\`,${cmd.name}\``)
                        .join(' '),
                    inline: false
                },
                {
                    name: 'ℹ️ Info',
                    value: commands.filter(cmd => cmd.category === 'info')
                        .map(cmd => `\`,${cmd.name}\``)
                        .join(' '),
                    inline: false
                }
            )
            .setFooter({ 
                text: `Total Commands: ${commands.size} | Use ,help <command> for more info`
            });

        message.channel.send({ embeds: [embed] });
    },
};
