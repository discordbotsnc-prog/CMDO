
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'onlinestatus',
    description: 'Change the bot\'s online status for this server',
    usage: ',onlinestatus <online/idle/dnd/offline>',
    category: 'utility',
    permissions: [PermissionFlagsBits.ManageGuild],
    cooldown: 5,
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Please specify a status: online, idle, dnd, or offline');
        }

        const status = args[0].toLowerCase();
        const validStatuses = {
            'online': { name: 'Online', emoji: '🟢' },
            'idle': { name: 'Idle', emoji: '🌙' },
            'dnd': { name: 'Do Not Disturb', emoji: '⛔' },
            'offline': { name: 'Offline', emoji: '⚫' }
        };

        if (!validStatuses[status]) {
            return message.reply('Invalid status! Please use: online, idle, dnd, or offline');
        }

        try {
            // Store the status preference for this server
            if (!message.client.serverStatuses) {
                message.client.serverStatuses = new Map();
            }
            message.client.serverStatuses.set(message.guild.id, status);
            
            // Save the status to file
            const statusPath = path.join(__dirname, '../../data/serverstatus.json');
            const data = {
                servers: Object.fromEntries(message.client.serverStatuses)
            };
            fs.writeFileSync(statusPath, JSON.stringify(data, null, 2));

            // Set the new status
            await message.client.user.setPresence({
                activities: message.client.user.presence.activities,
                status: status === 'offline' ? 'invisible' : status
            });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Status Updated')
                .setDescription(`${validStatuses[status].emoji} Bot status changed to **${validStatuses[status].name}** for this server`)
                .addFields(
                    { name: 'Permission Required', value: 'Manage Server' },
                    { name: 'Server', value: message.guild.name }
                )
                .setFooter({ text: `Changed by ${message.author.tag}` })
                .setTimestamp();

            message.channel.send({ embeds: [embed] });

        } catch (error) {
            console.error(error);
            message.reply('There was an error changing the bot\'s status!');
        }
    },
};
