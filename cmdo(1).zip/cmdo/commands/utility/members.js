
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'members',
    description: 'Shows the total number of members in the server',
    usage: ',members',
    category: 'utility',
    cooldown: 5,
    async execute(message) {
        const guild = message.guild;
        const totalMembers = guild.memberCount;
        const members = await guild.members.fetch();
        const botCount = members.filter(member => member.user.bot).size;
        const humanCount = totalMembers - botCount;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📊 Member Count')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: 'Total Members', value: `${totalMembers}`, inline: true },
                { name: 'Humans', value: `${humanCount}`, inline: true },
                { name: 'Bots', value: `${botCount}`, inline: true }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` })
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
