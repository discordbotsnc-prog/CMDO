const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'weather',
    description: 'Get current weather for a location',
    usage: ',weather <location>',
    category: 'utility',
    cooldown: 10,
    async execute(message, args) {
        if (!args.length) return message.reply('Please specify a location!');

        const location = args.join(' ');

        // Since we don't have an API key, we'll simulate weather data
        const conditions = ['Sunny', 'Cloudy', 'Rainy', 'Stormy', 'Snowy', 'Windy'];
        const temp = Math.floor(Math.random() * 35) + 5; // Random temp between 5-40°C
        const humidity = Math.floor(Math.random() * 50) + 30; // Random humidity 30-80%
        const condition = conditions[Math.floor(Math.random() * conditions.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`Weather in ${location}`)
            .addFields(
                { name: 'Temperature', value: `${temp}°C` },
                { name: 'Condition', value: condition },
                { name: 'Humidity', value: `${humidity}%` }
            )
            .setFooter({ text: 'Note: This is simulated weather data' });

        message.channel.send({ embeds: [embed] });
    },
};