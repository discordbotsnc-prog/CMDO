const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'avatar',
    description: 'Get user\'s avatar',
    usage: ',avatar [user]',
    category: 'utility',
    cooldown: 5,
    execute(message, args) {
        const target = message.mentions.users.first() || message.author;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`${target.username}'s Avatar`)
            .setImage(target.displayAvatarURL({ size: 4096, dynamic: true }))
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};