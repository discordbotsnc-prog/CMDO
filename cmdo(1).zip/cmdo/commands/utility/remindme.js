const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'remindme',
    description: 'Set a reminder',
    usage: ',remindme <time> <reminder>',
    category: 'utility',
    cooldown: 5,
    async execute(message, args) {
        if (args.length < 2) return message.reply('Please provide a time and reminder message!');

        const timeArg = args[0].toLowerCase();
        const reminder = args.slice(1).join(' ');

        // Convert time to milliseconds
        let ms = 0;
        if (timeArg.endsWith('s')) ms = parseInt(timeArg) * 1000;
        else if (timeArg.endsWith('m')) ms = parseInt(timeArg) * 60000;
        else if (timeArg.endsWith('h')) ms = parseInt(timeArg) * 3600000;
        else if (timeArg.endsWith('d')) ms = parseInt(timeArg) * 86400000;
        else return message.reply('Please specify time with s/m/h/d (e.g., 30s, 5m, 2h, 1d)');

        if (isNaN(ms)) return message.reply('Please provide a valid time!');
        if (ms < 1000 || ms > 2592000000) return message.reply('Reminder time must be between 1 second and 30 days!');

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('✅ Reminder Set')
            .setDescription(`I'll remind you about: ${reminder}`)
            .addFields({ name: 'Time', value: `${timeArg}` })
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });

        // Set the reminder
        setTimeout(async () => {
            const reminderEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('⏰ Reminder')
                .setDescription(reminder)
                .setFooter({ text: `Reminder from ${timeArg} ago` });

            try {
                await message.author.send({ embeds: [reminderEmbed] });
            } catch {
                message.channel.send({ content: `${message.author}`, embeds: [reminderEmbed] });
            }
        }, ms);
    },
};