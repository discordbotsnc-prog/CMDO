const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'translate',
    description: 'Simulate text translation (Note: This is a demo version)',
    usage: ',translate <language> <text>',
    category: 'utility',
    cooldown: 5,
    execute(message, args) {
        if (args.length < 2) {
            return message.reply('Please provide a language and text to translate!');
        }

        const targetLang = args[0].toLowerCase();
        const text = args.slice(1).join(' ');

        // Simulated translations (for demo purposes)
        const translations = {
            'spanish': text + ' (en español)',
            'french': text + ' (en français)',
            'german': text + ' (auf Deutsch)',
            'italian': text + ' (in italiano)',
            'japanese': text + ' (日本語で)',
            'korean': text + ' (한국어로)',
            'russian': text + ' (по-русски)',
            'chinese': text + ' (用中文)',
        };

        if (!translations[targetLang]) {
            return message.reply('Supported languages: spanish, french, german, italian, japanese, korean, russian, chinese');
        }

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Translation')
            .addFields(
                { name: 'Original Text', value: text },
                { name: `Translated to ${targetLang.charAt(0).toUpperCase() + targetLang.slice(1)}`, value: translations[targetLang] }
            )
            .setFooter({ text: 'Note: This is a demo translation' });

        message.channel.send({ embeds: [embed] });
    },
};