
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'invites',
    description: 'Shows how many people you have invited to the server',
    usage: ',invites [user]',
    category: 'utility',
    cooldown: 5,
    async execute(message, args) {
        try {
            const target = message.mentions.users.first() || message.author;
            const invitesPath = path.join(__dirname, '../../data/invites.json');
            
            // Load invites data
            let invitesData = { invites: {} };
            if (fs.existsSync(invitesPath)) {
                invitesData = JSON.parse(fs.readFileSync(invitesPath));
            }

            // Get guild invites
            const guildInvites = await message.guild.invites.fetch();
            
            // Count user's invites
            let userInvites = 0;
            guildInvites.forEach(invite => {
                if (invite.inviter && invite.inviter.id === target.id) {
                    userInvites += invite.uses;
                }
            });

            // Store the invites count
            if (!invitesData.invites[message.guild.id]) {
                invitesData.invites[message.guild.id] = {};
            }
            if (!invitesData.invites[message.guild.id][target.id]) {
                invitesData.invites[message.guild.id][target.id] = 0;
            }
            if (userInvites > invitesData.invites[message.guild.id][target.id]) {
                invitesData.invites[message.guild.id][target.id] = userInvites;
            }

            // Save to file
            fs.writeFileSync(invitesPath, JSON.stringify(invitesData, null, 2));

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('📨 Server Invites')
                .setDescription(`${target.id === message.author.id ? 'You have' : `${target.tag} has`} invited **${invitesData.invites[target.id]}** member${invitesData.invites[target.id] === 1 ? '' : 's'} to the server!`)
                .setTimestamp();

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error in invites command:', error);
            message.reply('An error occurred while fetching invites!');
        }
    }
};
