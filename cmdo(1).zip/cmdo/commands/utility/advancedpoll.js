const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'advancedpoll',
    description: 'Create a poll with multiple options',
    usage: ',advancedpoll <question> | <option1> | <option2> | [option3] ...',
    category: 'utility',
    cooldown: 10,
    async execute(message, args) {
        const input = args.join(' ').split('|').map(item => item.trim());

        if (input.length < 3) {
            return message.reply('Please provide a question and at least 2 options! Format: ,advancedpoll Question | Option1 | Option2');
        }

        const [question, ...options] = input;

        if (options.length > 10) {
            return message.reply('You can only have up to 10 options!');
        }

        const reactions = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📊 ' + question)
            .setDescription(
                options.map((option, i) => `${reactions[i]} ${option}`).join('\n\n')
            )
            .setFooter({ text: `Created by ${message.author.tag}` });

        const poll = await message.channel.send({ embeds: [embed] });

        for (let i = 0; i < options.length; i++) {
            await poll.react(reactions[i]);
        }
    },
};