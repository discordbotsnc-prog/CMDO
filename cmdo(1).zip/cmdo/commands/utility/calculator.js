const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'calculator',
    description: 'Perform basic math calculations',
    usage: ',calculator <expression>',
    aliases: ['calc', 'math'],
    category: 'utility',
    cooldown: 3,
    execute(message, args) {
        if (!args.length) return message.reply('Please provide a math expression!');

        const expression = args.join(' ')
            .replace(/[^0-9+\-*/().]/g, '')
            .replace(/\s+/g, '');

        if (!expression) return message.reply('Please provide a valid math expression!');

        let result;
        try {
            // Using Function instead of eval for better security
            result = new Function('return ' + expression)();

            if (!isFinite(result)) throw new Error('Invalid calculation');

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Calculator')
                .addFields(
                    { name: 'Expression', value: expression },
                    { name: 'Result', value: result.toString() }
                );

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            message.reply('Invalid expression! Please try again with a valid math expression.');
        }
    },
};