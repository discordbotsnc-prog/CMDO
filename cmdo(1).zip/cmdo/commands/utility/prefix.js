
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'prefix',
    description: 'Set a custom prefix for this server',
    usage: ',prefix <new prefix>',
    category: 'utility',
    permissions: [PermissionFlagsBits.ManageGuild],
    cooldown: 5,
    execute(message, args) {
        if (!args.length) {
            return message.reply('Please specify a new prefix!');
        }

        const newPrefix = args[0];
        if (newPrefix.length > 3) {
            return message.reply('Prefix cannot be longer than 3 characters!');
        }

        // Initialize server prefixes if not exists
        if (!message.client.serverPrefixes) {
            message.client.serverPrefixes = new Map();
        }

        // Set the new prefix for this server
        message.client.serverPrefixes.set(message.guild.id, newPrefix);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Prefix Updated')
            .setDescription(`Server prefix has been updated to: \`${newPrefix}\``)
            .setFooter({ text: `Changed by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};
