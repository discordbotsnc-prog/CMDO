const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'timestamp',
    description: 'Convert time to Discord timestamps',
    usage: ',timestamp [time]',
    category: 'utility',
    cooldown: 3,
    execute(message, args) {
        const now = new Date();
        let targetDate = now;

        if (args.length > 0) {
            const timeArg = args.join(' ').toLowerCase();
            const amount = parseInt(timeArg);

            if (!isNaN(amount)) {
                if (timeArg.includes('minute') || timeArg.includes('min')) {
                    targetDate = new Date(now.getTime() + amount * 60000);
                } else if (timeArg.includes('hour') || timeArg.includes('hr')) {
                    targetDate = new Date(now.getTime() + amount * 3600000);
                } else if (timeArg.includes('day')) {
                    targetDate = new Date(now.getTime() + amount * 86400000);
                } else {
                    return message.reply('Please specify time with minutes/hours/days (e.g., 30 minutes, 2 hours, 1 day)');
                }
            } else {
                return message.reply('Please provide a valid time amount!');
            }
        }

        const timestamp = Math.floor(targetDate.getTime() / 1000);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Discord Timestamps')
            .setDescription('Copy these timestamps to use in your messages:')
            .addFields(
                { name: 'Default', value: `\`<t:${timestamp}>\` → <t:${timestamp}>` },
                { name: 'Short Time', value: `\`<t:${timestamp}:t>\` → <t:${timestamp}:t>` },
                { name: 'Long Time', value: `\`<t:${timestamp}:T>\` → <t:${timestamp}:T>` },
                { name: 'Short Date', value: `\`<t:${timestamp}:d>\` → <t:${timestamp}:d>` },
                { name: 'Long Date', value: `\`<t:${timestamp}:D>\` → <t:${timestamp}:D>` },
                { name: 'Short Date/Time', value: `\`<t:${timestamp}:f>\` → <t:${timestamp}:f>` },
                { name: 'Long Date/Time', value: `\`<t:${timestamp}:F>\` → <t:${timestamp}:F>` },
                { name: 'Relative', value: `\`<t:${timestamp}:R>\` → <t:${timestamp}:R>` }
            );

        message.channel.send({ embeds: [embed] });
    },
};