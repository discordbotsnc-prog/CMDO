const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'userinfo',
    description: 'Display information about a user',
    usage: ',userinfo [user]',
    category: 'utility',
    cooldown: 5,
    async execute(message, args) {
        const target = message.mentions.users.first() || 
            await message.client.users.fetch(args[0]).catch(() => message.author) || 
            message.author;

        const member = message.guild.members.cache.get(target.id);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('User Information')
            .setThumbnail(target.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: 'Username', value: target.tag },
                { name: 'ID', value: target.id },
                { name: 'Nickname', value: member.nickname || 'None' },
                { name: 'Account Created', value: target.createdAt.toLocaleDateString() },
                { name: 'Joined Server', value: member.joinedAt.toLocaleDateString() },
                { name: 'Roles', value: member.roles.cache.map(r => r.name).join(', ') }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};