const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'serverinfo',
    description: 'Display information about the server',
    usage: ',serverinfo',
    category: 'utility',
    cooldown: 5,
    async execute(message) {
        const guild = message.guild;
        const owner = await guild.fetchOwner();

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Server Information')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: 'Server Name', value: guild.name },
                { name: 'Server ID', value: guild.id },
                { name: 'Owner', value: `${owner.user.tag}` },
                { name: 'Members', value: `${guild.memberCount}` },
                { name: 'Channels', value: `${guild.channels.cache.size}` },
                { name: 'Roles', value: `${guild.roles.cache.size}` },
                { name: 'Created At', value: guild.createdAt.toLocaleDateString() }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};