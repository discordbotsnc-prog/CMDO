const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'serverstats',
    description: 'View detailed server statistics',
    usage: ',serverstats',
    category: 'utility',
    cooldown: 10,
    async execute(message) {
        const guild = message.guild;
        const totalMembers = guild.memberCount;
        const members = await guild.members.fetch();

        // Calculate various statistics
        const botCount = members.filter(member => member.user.bot).size;
        const humanCount = totalMembers - botCount;
        const onlineCount = members.filter(member => member.presence?.status === 'online').size;

        // Get member join dates statistics
        const sortedMembers = [...members.values()].sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
        const oldestMember = sortedMembers[0];
        const newestMember = sortedMembers[sortedMembers.length - 1];

        // Calculate server age in days
        const serverAge = Math.floor((Date.now() - guild.createdTimestamp) / (1000 * 60 * 60 * 24));

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📊 Server Statistics')
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: 'Total Members', value: `${totalMembers}`, inline: true },
                { name: 'Humans', value: `${humanCount}`, inline: true },
                { name: 'Bots', value: `${botCount}`, inline: true },
                { name: 'Online Members', value: `${onlineCount}`, inline: true },
                { name: 'Server Age', value: `${serverAge} days`, inline: true },
                { name: 'Channel Count', value: `${guild.channels.cache.size}`, inline: true },
                { name: 'Role Count', value: `${guild.roles.cache.size}`, inline: true },
                { name: 'Emoji Count', value: `${guild.emojis.cache.size}`, inline: true },
                { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true },
                { name: 'Boost Count', value: `${guild.premiumSubscriptionCount || 0}`, inline: true },
                { name: 'First Member', value: oldestMember ? `${oldestMember.user.tag} (${new Date(oldestMember.joinedTimestamp).toLocaleDateString()})` : 'Unknown', inline: false },
                { name: 'Newest Member', value: newestMember ? `${newestMember.user.tag} (${new Date(newestMember.joinedTimestamp).toLocaleDateString()})` : 'Unknown', inline: false }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` })
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};