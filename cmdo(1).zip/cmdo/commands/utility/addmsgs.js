
const { EmbedBuilder } = require('discord.js');
const { ownerID } = require('../../config');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'addmsgs',
    description: 'Add to message count (Owner only)',
    usage: ',addmsgs @user <limit>',
    category: 'utility',
    cooldown: 5,
    async execute(message, args) {
        if (message.author.id !== ownerID) {
            return message.reply('This command is restricted to the bot owner.');
        }

        const target = message.mentions.users.first();
        if (!target) {
            return message.reply('Please mention a user to add messages to.');
        }

        if (!args[1]) {
            return message.reply('Please provide a number of messages to add.');
        }

        const limit = parseInt(args[1]);
        if (isNaN(limit) || limit <= 0) {
            return message.reply('Please provide a valid positive number.');
        }

        try {
            const messagesPath = path.join(__dirname, '../../data/messages.json');
            let messageData = { addedMessages: {} };
            
            if (fs.existsSync(messagesPath)) {
                messageData = JSON.parse(fs.readFileSync(messagesPath));
            }

            const guildId = message.guild.id;
            const userId = target.id;

            // Initialize server data if it doesn't exist
            if (!messageData.addedMessages[guildId]) {
                messageData.addedMessages[guildId] = {};
            }

            // Add messages to user's count
            messageData.addedMessages[guildId][userId] = (messageData.addedMessages[guildId][userId] || 0) + limit;

            // Save to file
            fs.writeFileSync(messagesPath, JSON.stringify(messageData, null, 2));

            // Calculate total messages
            const messages = await message.channel.messages.fetch({ limit: 100 });
            const userMessages = messages.filter(msg => msg.author.id === target.id);
            const totalCount = userMessages.size + messageData.addedMessages[guildId][userId];

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Messages Added')
                .setDescription(`Added ${limit} messages to ${target.username}'s count.\nNew total: ${totalCount}`)
                .setFooter({ text: `Requested by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error adding messages:', error);
            message.reply('There was an error adding messages.');
        }
    },
};
