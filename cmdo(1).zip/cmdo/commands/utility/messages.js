
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'msgs',
    description: 'Shows your message count in the server',
    usage: ',msg',
    category: 'utility',
    cooldown: 10,
    async execute(message) {
        try {
            const target = message.mentions.users.first() || message.author;
            const messages = await message.channel.messages.fetch({ limit: 100 });
            const userMessages = messages.filter(msg => msg.author.id === target.id);
            
            // Get added messages from file
            const messagesPath = path.join(__dirname, '../../data/messages.json');
            let messageData = { addedMessages: {} };
            if (fs.existsSync(messagesPath)) {
                messageData = JSON.parse(fs.readFileSync(messagesPath));
            }

            const guildId = message.guild.id;
            const userId = target.id;
            const addedCount = messageData.addedMessages[guildId]?.[userId] || 0;
            const totalCount = userMessages.size + addedCount;
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`${target.username}'s Message Count`)
                .setDescription(`${target.id === message.author.id ? 'You have' : `${target.username} has`} sent **${totalCount}** messages`)
                .setFooter({ text: `Requested by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching messages:', error);
            message.reply('There was an error fetching your messages.');
        }
    },
};
