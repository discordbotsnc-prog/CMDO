const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ping',
    description: 'Check the bot\'s latency',
    usage: ',ping',
    category: 'utility',
    cooldown: 5,
    async execute(message) {
        const sent = await message.channel.send('Pinging...');

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🏓 Pong!')
            .addFields(
                { name: 'Latency', value: `${sent.createdTimestamp - message.createdTimestamp}ms` },
                { name: 'API Latency', value: `${Math.round(message.client.ws.ping)}ms` }
            );

        sent.edit({ content: null, embeds: [embed] });
    },
};