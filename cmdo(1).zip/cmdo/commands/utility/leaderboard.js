
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'leaderboard',
    aliases: ['leaderboard msgs', 'leaderboard invites'],
    description: 'Shows the message leaderboard',
    usage: ',leaderboard msgs',
    category: 'utility',
    cooldown: 10,
    async execute(message, args) {
        try {
            const type = args[0]?.toLowerCase() || 'msgs';
            
            if (type === 'invites') {
                const invitesPath = path.join(__dirname, '../../data/invites.json');
                let invitesData = { invites: {} };
                
                if (fs.existsSync(invitesPath)) {
                    invitesData = JSON.parse(fs.readFileSync(invitesPath));
                }

                // Convert to array and sort
                let leaderboard = Object.entries(invitesData.invites)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 10);

                // Create leaderboard text
                let description = '**📨 Invites Leaderboard**\n\n';
                for (let i = 0; i < leaderboard.length; i++) {
                    const userId = leaderboard[i][0];
                    const count = leaderboard[i][1];
                    const member = await message.guild.members.fetch(userId).catch(() => null);
                    if (member) {
                        description += `${i + 1}. ${member.user.username}: **${count}** invites\n`;
                    }
                }

                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Invites Leaderboard')
                    .setDescription(description)
                    .setFooter({ text: `Requested by ${message.author.tag}` })
                    .setTimestamp();

                return message.channel.send({ embeds: [embed] });
            }

            const messages = await message.channel.messages.fetch({ limit: 100 });
            const messagesPath = path.join(__dirname, '../../data/messages.json');
            let addedMessages = {};
            
            if (fs.existsSync(messagesPath)) {
                const data = JSON.parse(fs.readFileSync(messagesPath));
                addedMessages = data.addedMessages?.[message.guild.id] || {};
            }

            // Count messages per user
            let userCounts = new Map();
            messages.forEach(msg => {
                const count = userCounts.get(msg.author.id) || 0;
                userCounts.set(msg.author.id, count + 1);
            });

            // Add the stored messages
            for (const [userId, count] of Object.entries(addedMessages)) {
                const current = userCounts.get(userId) || 0;
                userCounts.set(userId, current + count);
            }

            // Convert to array and sort
            let leaderboard = [...userCounts.entries()]
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);

            // Create leaderboard text
            let description = '**📊 Message Leaderboard**\n\n';
            for (let i = 0; i < leaderboard.length; i++) {
                const userId = leaderboard[i][0];
                const count = leaderboard[i][1];
                const member = await message.guild.members.fetch(userId).catch(() => null);
                if (member) {
                    description += `${i + 1}. ${member.user.username}: **${count}** messages\n`;
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Message Leaderboard')
                .setDescription(description)
                .setFooter({ text: `Requested by ${message.author.tag}` })
                .setTimestamp();

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error in leaderboard command:', error);
            message.reply('There was an error fetching the leaderboard!');
        }
    },
};
