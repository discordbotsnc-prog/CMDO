const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'joke',
    description: 'Get a random joke',
    usage: ',joke',
    category: 'fun',
    cooldown: 3,
    execute(message) {
        const jokes = [
            { setup: 'Why don\'t pirates take a shower before they walk the plank?', punchline: 'They just wash up on shore!' },
            { setup: 'Why did the scarecrow win an award?', punchline: 'He was outstanding in his field!' },
            { setup: 'What do you call a bear with no teeth?', punchline: 'A gummy bear!' },
            { setup: 'What do you call a fake noodle?', punchline: 'An impasta!' },
            { setup: 'Why did the cookie go to the doctor?', punchline: 'Because it was feeling crumbly!' }
        ];

        const joke = jokes[Math.floor(Math.random() * jokes.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('😄 Random Joke')
            .addFields(
                { name: 'Setup', value: joke.setup },
                { name: 'Punchline', value: joke.punchline }
            );

        message.channel.send({ embeds: [embed] });
    },
};