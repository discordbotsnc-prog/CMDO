const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'emojify',
    description: 'Convert text to emoji letters',
    usage: ',emojify <text>',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!args.length) return message.reply('Please provide some text to emojify!');

        const mapping = {
            ' ': '   ',
            '0': ':zero:',
            '1': ':one:',
            '2': ':two:',
            '3': ':three:',
            '4': ':four:',
            '5': ':five:',
            '6': ':six:',
            '7': ':seven:',
            '8': ':eight:',
            '9': ':nine:',
            '!': ':exclamation:',
            '?': ':question:',
            '#': ':hash:',
            '*': ':asterisk:'
        };

        'abcdefghijklmnopqrstuvwxyz'.split('').forEach(c => {
            mapping[c] = mapping[c.toUpperCase()] = `:regional_indicator_${c}:`;
        });

        const text = args.join(' ').toLowerCase().split('').map(c => mapping[c] || c).join('');

        if (text.length > 2000) {
            return message.reply('The emojified text is too long!');
        }

        message.channel.send(text);
    },
};