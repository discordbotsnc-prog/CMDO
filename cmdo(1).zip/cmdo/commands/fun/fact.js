
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'fact',
    description: 'Get a random fact',
    usage: ',fact',
    category: 'fun',
    cooldown: 5,
    execute(message) {
        const facts = [
            "Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old!",
            "A day on Venus is longer than its year.",
            "The first oranges weren't orange.",
            "A shark can detect a fish's heartbeat before it attacks.",
            "Bananas are berries, but strawberries aren't."
        ];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🤓 Random Fact')
            .setDescription(facts[Math.floor(Math.random() * facts.length)]);

        message.channel.send({ embeds: [embed] });
    },
};
