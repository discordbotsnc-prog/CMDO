const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'talkabout',
    description: 'Set a topic for the chatting bot to talk about',
    usage: ',talkabout <topic>',
    category: 'fun',
    cooldown: 3,
    execute(message, args, client) {
        if (!client.chattingEnabled) {
            client.chattingEnabled = new Map();
        }
        if (!client.chattingTopics) {
            client.chattingTopics = new Map();
        }

        const channelId = message.channel.id;
        const topic = args.join(' ');

        if (!topic) {
            const currentTopic = client.chattingTopics.get(channelId) || 'No topic set';
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Talk About')
                .setDescription('Set a topic for the chatting bot to discuss')
                .addFields(
                    { name: 'Current Topic', value: currentTopic },
                    { name: 'Usage', value: '`,talkabout <topic>` - Example: `,talkabout video games`' }
                )
                .setFooter({ text: `Requested by ${message.author.tag}` });

            return message.channel.send({ embeds: [embed] });
        }

        client.chattingTopics.set(channelId, topic);
        
        if (!client.chattingEnabled.get(channelId)) {
            client.chattingEnabled.set(channelId, true);
        }

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('Topic Set!')
            .setDescription(`I'll now talk about: **${topic}**`)
            .addFields(
                { name: 'Chatting Status', value: 'Enabled', inline: true }
            )
            .setFooter({ text: `Set by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};
