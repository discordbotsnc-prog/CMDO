const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'play',
    description: 'Add a YouTube song to the queue',
    usage: ',play <song name>',
    category: 'fun',
    cooldown: 3,
    async execute(message, args, client) {
        try {
            if (args.length === 0) {
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('❌ Missing Song')
                    .setDescription('Usage: `,play <song name>`')
                    .setFooter({ text: 'Example: ,play Blinding Lights' });
                return message.reply({ embeds: [embed] });
            }

            // Initialize music queue if needed
            if (!client.musicQueues) client.musicQueues = new Map();
            if (!client.musicQueues.has(message.guild.id)) {
                client.musicQueues.set(message.guild.id, []);
            }

            const query = args.join(' ');
            const player = client.player;
            
            const searchMsg = await message.reply({ embeds: [new EmbedBuilder().setColor('#FFA500').setTitle('🔍 Searching YouTube...').setDescription(`Looking for: ${query}`)] });

            let searchResult;
            try {
                // Force YouTube search
                searchResult = await player.search(`ytsearch:${query}`, { requestedBy: message.author });
            } catch (err) {
                console.error('YouTube search error:', err);
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('❌ Search Failed')
                    .setDescription('Could not search YouTube. Try a different song name.');
                return searchMsg.edit({ embeds: [embed] });
            }

            if (!searchResult || searchResult.tracks.length === 0) {
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('❌ No Results')
                    .setDescription(`No songs found for "${query}" on YouTube`);
                return searchMsg.edit({ embeds: [embed] });
            }

            const track = searchResult.tracks[0];
            const queue = client.musicQueues.get(message.guild.id);
            
            // Add to queue
            queue.push({
                title: track.title,
                author: track.author || 'YouTube',
                url: track.url,
                duration: formatDuration(track.durationMS),
                thumbnail: track.thumbnail,
                requestedBy: message.author.username
            });

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('🎵 Added to Queue')
                .setDescription(`[${track.title}](${track.url})`)
                .addFields(
                    { name: 'Channel', value: track.author || 'Unknown', inline: true },
                    { name: 'Duration', value: formatDuration(track.durationMS), inline: true },
                    { name: 'Position', value: `#${queue.length}`, inline: true }
                )
                .setFooter({ text: `Requested by ${message.author.username}` });

            if (track.thumbnail) embed.setThumbnail(track.thumbnail);

            await searchMsg.edit({ embeds: [embed] });

        } catch (error) {
            console.error('Play command error:', error);
            message.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Error').setDescription('An error occurred! Try again.')] });
        }
    }
};

function formatDuration(ms) {
    if (!ms) return 'Unknown';
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}
