const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'queue',
    description: 'Display the music queue',
    usage: ',queue',
    category: 'fun',
    cooldown: 2,
    execute(message, args, client) {
        if (!client.musicQueues || !client.musicQueues.has(message.guild.id)) {
            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('🎵 Queue')
                .setDescription('Queue is empty. Use `,play <song>` to add songs!');
            return message.reply({ embeds: [embed] });
        }

        const queue = client.musicQueues.get(message.guild.id);
        
        if (queue.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('🎵 Queue')
                .setDescription('Queue is empty. Use `,play <song>` to add songs!');
            return message.reply({ embeds: [embed] });
        }

        let description = '';
        queue.slice(0, 10).forEach((track, index) => {
            description += `**${index + 1}.** [${track.title}](${track.url})\n`;
            description += `   Artist: ${track.author} • Duration: ${track.duration}\n\n`;
        });

        if (queue.length > 10) {
            description += `... and ${queue.length - 10} more songs`;
        }

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🎵 Music Queue')
            .setDescription(description)
            .setFooter({ text: `Total: ${queue.length} song(s)` });

        message.reply({ embeds: [embed] });
    }
};
