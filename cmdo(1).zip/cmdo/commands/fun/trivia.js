
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'trivia',
    description: 'Play a trivia game',
    usage: ',trivia',
    category: 'fun',
    cooldown: 5,
    async execute(message) {
        const triviaQuestions = [
            { q: "What planet is known as the Red Planet?", a: "Mars" },
            { q: "Who painted the Mona Lisa?", a: "Leonardo da Vinci" },
            { q: "What is the capital of Japan?", a: "Tokyo" },
            { q: "Which element has the symbol 'Au'?", a: "Gold" },
            { q: "What is the largest mammal in the world?", a: "Blue Whale" }
        ];

        const question = triviaQuestions[Math.floor(Math.random() * triviaQuestions.length)];
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🎯 Trivia Time!')
            .setDescription(question.q)
            .setFooter({ text: 'You have 30 seconds to answer!' });

        const questionMsg = await message.channel.send({ embeds: [embed] });
        
        try {
            const collected = await message.channel.awaitMessages({
                filter: m => m.author.id === message.author.id,
                max: 1,
                time: 30000
            });

            if (collected.first().content.toLowerCase() === question.a.toLowerCase()) {
                message.channel.send('🎉 Correct answer!');
            } else {
                message.channel.send(`❌ Wrong! The correct answer was: ${question.a}`);
            }
        } catch (error) {
            message.channel.send('Time\'s up! No answer provided.');
        }
    },
};
