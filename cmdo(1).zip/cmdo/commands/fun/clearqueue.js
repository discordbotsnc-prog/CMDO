const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'clearqueue',
    description: 'Clear the entire music queue',
    usage: ',clearqueue',
    aliases: ['cq'],
    category: 'fun',
    cooldown: 2,
    execute(message, args, client) {
        if (!client.musicQueues || !client.musicQueues.has(message.guild.id)) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ No Queue')
                .setDescription('There\'s no music queue to clear!');
            return message.reply({ embeds: [embed] });
        }

        const queue = client.musicQueues.get(message.guild.id);
        const count = queue.length;

        if (count === 0) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Queue Already Empty')
                .setDescription('The queue is already empty!');
            return message.reply({ embeds: [embed] });
        }

        queue.length = 0;

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🗑️ Queue Cleared')
            .setDescription(`Cleared ${count} song(s) from the queue.`);

        message.reply({ embeds: [embed] });
    }
};
