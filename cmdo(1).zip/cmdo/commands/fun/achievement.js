const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'achievement',
    description: 'Create a Minecraft-style achievement message',
    usage: ',achievement <text>',
    category: 'fun',
    cooldown: 5,
    execute(message, args) {
        if (!args.length) return message.reply('Please provide text for the achievement!');

        const text = args.join(' ');
        if (text.length > 50) return message.reply('Achievement text must be 50 characters or less!');

        // Using emojis to simulate achievement
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🏆 Achievement Get!')
            .setDescription(`\`\`\`${text}\`\`\``)
            .setFooter({ text: `Unlocked by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};