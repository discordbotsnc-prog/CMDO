
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'riddle',
    description: 'Get a random riddle',
    usage: ',riddle',
    category: 'fun',
    cooldown: 5,
    async execute(message) {
        const riddles = [
            { q: "What has keys, but no locks; space, but no room; and you can enter, but not go in?", a: "A keyboard" },
            { q: "What gets wetter and wetter the more it dries?", a: "A towel" },
            { q: "What has a head and a tail that will never meet?", a: "A coin" },
            { q: "What has cities, but no houses; forests, but no trees; and rivers, but no water?", a: "A map" }
        ];

        const riddle = riddles[Math.floor(Math.random() * riddles.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🤔 Riddle')
            .setDescription(riddle.q)
            .setFooter({ text: 'Answer will be revealed in 30 seconds!' });

        const riddleMsg = await message.channel.send({ embeds: [embed] });
        
        setTimeout(() => {
            const answerEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🎯 Riddle Answer')
                .setDescription(`Q: ${riddle.q}\nA: ${riddle.a}`);
            
            message.channel.send({ embeds: [answerEmbed] });
        }, 30000);
    },
};
