const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interact',
    description: 'Interact with other users using various actions',
    usage: ',interact <action> <user>',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (args.length < 2) {
            return message.reply('Please specify an action and a user! Example: ,interact hug @user');
        }

        const action = args[0].toLowerCase();
        const target = message.mentions.users.first();

        if (!target) {
            return message.reply('Please mention a valid user!');
        }

        if (target.id === message.author.id) {
            return message.reply('You cannot interact with yourself!');
        }

        const actions = {
            hug: {
                text: 'hugs',
                emojis: ['🤗', '💝', '💖'],
                messages: [
                    'spreads love and warmth!',
                    'gives a big bear hug!',
                    'shares a heartwarming embrace!'
                ]
            },
            highfive: {
                text: 'high-fives',
                emojis: ['✋', '🙌', '👏'],
                messages: [
                    'celebrates with style!',
                    'shares the victory!',
                    'shows team spirit!'
                ]
            },
            wave: {
                text: 'waves at',
                emojis: ['👋', '✌️', '🌟'],
                messages: [
                    'sends friendly greetings!',
                    'spreads positive vibes!',
                    'shows friendship!'
                ]
            },
            dance: {
                text: 'dances with',
                emojis: ['💃', '🕺', '🎵'],
                messages: [
                    'starts a dance party!',
                    'shows off some moves!',
                    'grooves to the beat!'
                ]
            }
        };

        if (!actions[action]) {
            return message.reply(`Available actions: ${Object.keys(actions).join(', ')}`);
        }

        const selectedAction = actions[action];
        const emoji = selectedAction.emojis[Math.floor(Math.random() * selectedAction.emojis.length)];
        const actionMessage = selectedAction.messages[Math.floor(Math.random() * selectedAction.messages.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`${emoji} Interaction`)
            .setDescription(`**${message.author}** ${selectedAction.text} **${target}** and ${actionMessage}`)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};