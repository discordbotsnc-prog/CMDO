
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'dare',
    description: 'Get a random dare',
    usage: ',dare',
    category: 'fun',
    cooldown: 5,
    execute(message) {
        const dares = [
            "Change your Discord status to something silly for an hour",
            "Type everything backwards for the next 5 minutes",
            "Tell us your best joke",
            "Speak in emojis only for the next 3 messages",
            "Write a haiku about your favorite video game"
        ];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('😈 I Dare You To...')
            .setDescription(dares[Math.floor(Math.random() * dares.length)])
            .setFooter({ text: 'Do you accept the challenge?' });

        message.channel.send({ embeds: [embed] });
    },
};
