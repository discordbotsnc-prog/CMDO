const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'rps',
    description: 'Play Rock, Paper, Scissors with the bot',
    usage: ',rps <rock|paper|scissors>',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!args[0]) return message.reply('Please choose rock, paper, or scissors!');

        const choices = ['rock', 'paper', 'scissors'];
        const choice = args[0].toLowerCase();

        if (!choices.includes(choice)) {
            return message.reply('Please choose rock, paper, or scissors!');
        }

        const botChoice = choices[Math.floor(Math.random() * choices.length)];
        let result;

        if (choice === botChoice) result = 'Tie!';
        else if (
            (choice === 'rock' && botChoice === 'scissors') ||
            (choice === 'paper' && botChoice === 'rock') ||
            (choice === 'scissors' && botChoice === 'paper')
        ) result = 'You win!';
        else result = 'I win!';

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Rock Paper Scissors')
            .addFields(
                { name: 'Your Choice', value: choice },
                { name: 'My Choice', value: botChoice },
                { name: 'Result', value: result }
            );

        message.channel.send({ embeds: [embed] });
    },
};