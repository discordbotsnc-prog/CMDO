const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'dice',
    description: 'Roll a dice with specified number of sides',
    usage: ',dice [sides]',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        const sides = args[0] ? parseInt(args[0]) : 6;

        if (isNaN(sides) || sides < 1) {
            return message.reply('Please provide a valid number of sides!');
        }

        const result = Math.floor(Math.random() * sides) + 1;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🎲 Dice Roll')
            .setDescription(`Rolling a ${sides}-sided dice...`)
            .addFields({ name: 'Result', value: result.toString() });

        message.channel.send({ embeds: [embed] });
    },
};