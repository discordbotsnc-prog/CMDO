const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'skip',
    description: 'Skip to the next song in the queue',
    usage: ',skip',
    category: 'fun',
    cooldown: 2,
    execute(message, args, client) {
        if (!client.musicQueues || !client.musicQueues.has(message.guild.id)) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ No Queue')
                .setDescription('There\'s no music queue. Use `,play <song>` to start!');
            return message.reply({ embeds: [embed] });
        }

        const queue = client.musicQueues.get(message.guild.id);
        
        if (queue.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Queue Empty')
                .setDescription('The queue is empty!');
            return message.reply({ embeds: [embed] });
        }

        const skipped = queue.shift();
        
        if (queue.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('⏭️ Skipped')
                .setDescription(`Skipped: [${skipped.title}](${skipped.url})\n\nQueue is now empty.`);
            return message.reply({ embeds: [embed] });
        }

        const next = queue[0];
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('⏭️ Skipped')
            .setDescription(`Skipped: [${skipped.title}](${skipped.url})\n\n**Now Playing:**\n[${next.title}](${next.url})`)
            .setFooter({ text: `${queue.length} song(s) remaining` });

        if (next.thumbnail) embed.setThumbnail(next.thumbnail);

        message.reply({ embeds: [embed] });
    }
};
