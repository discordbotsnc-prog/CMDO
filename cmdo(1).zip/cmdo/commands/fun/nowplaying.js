const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'nowplaying',
    description: 'Show the currently playing song',
    usage: ',nowplaying',
    aliases: ['np', 'current'],
    category: 'fun',
    cooldown: 2,
    execute(message, args, client) {
        if (!client.musicQueues || !client.musicQueues.has(message.guild.id)) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Nothing Playing')
                .setDescription('The queue is empty. Use `,play <song>` to start!');
            return message.reply({ embeds: [embed] });
        }

        const queue = client.musicQueues.get(message.guild.id);
        
        if (queue.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('❌ Nothing Playing')
                .setDescription('The queue is empty. Use `,play <song>` to start!');
            return message.reply({ embeds: [embed] });
        }

        const track = queue[0];
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🎵 Now Playing')
            .setDescription(`[${track.title}](${track.url})`)
            .addFields(
                { name: 'Artist', value: track.author, inline: true },
                { name: 'Duration', value: track.duration, inline: true },
                { name: 'Requested by', value: track.requestedBy, inline: true }
            )
            .setFooter({ text: `${queue.length} song(s) in queue` });

        if (track.thumbnail) embed.setThumbnail(track.thumbnail);

        message.reply({ embeds: [embed] });
    }
};
