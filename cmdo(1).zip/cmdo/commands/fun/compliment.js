
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'compliment',
    description: 'Get a random compliment',
    usage: ',compliment [@user]',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        const compliments = [
            "You're amazing!",
            "You light up the room!",
            "You make a difference in the world!",
            "You're one of a kind!",
            "Your positivity is contagious!"
        ];

        const target = message.mentions.users.first() || message.author;
        const compliment = compliments[Math.floor(Math.random() * compliments.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('💝 Compliment')
            .setDescription(`${target}: ${compliment}`);

        message.channel.send({ embeds: [embed] });
    },
};
