
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'reverse',
    description: 'Reverse your text',
    usage: ',reverse <text>',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!args.length) return message.reply('Please provide text to reverse!');
        
        const reversed = args.join(' ').split('').reverse().join('');
        
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('⏪ Reversed Text')
            .addFields(
                { name: 'Original', value: args.join(' ') },
                { name: 'Reversed', value: reversed }
            );

        message.channel.send({ embeds: [embed] });
    },
};
