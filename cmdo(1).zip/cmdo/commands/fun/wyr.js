
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'wyr',
    description: 'Play Would You Rather',
    usage: ',wyr',
    category: 'fun',
    cooldown: 5,
    execute(message) {
        const questions = [
            { a: "be able to fly", b: "be able to read minds" },
            { a: "live in space", b: "live under the ocean" },
            { a: "have unlimited money", b: "have unlimited knowledge" },
            { a: "be invisible", b: "be super fast" },
            { a: "always speak your mind", b: "never speak again" }
        ];

        const question = questions[Math.floor(Math.random() * questions.length)];
        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Would You Rather...')
            .addFields(
                { name: '🅰️', value: question.a },
                { name: '🅱️', value: question.b }
            );

        message.channel.send({ embeds: [embed] });
    },
};
