const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'balance',
    description: 'Check your virtual balance',
    usage: ',balance [user]',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!message.client.balances) message.client.balances = new Map();

        const target = message.mentions.users.first() || message.author;
        const balance = message.client.balances.get(target.id) || 0;

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('💰 Balance Check')
            .setDescription(`**${target.tag}** has **${balance}** coins`)
            .setFooter({ text: 'Use ,daily to earn coins!' });

        message.channel.send({ embeds: [embed] });
    },
};