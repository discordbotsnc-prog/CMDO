
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'fortune',
    description: 'Get your fortune cookie',
    usage: ',fortune',
    category: 'fun',
    cooldown: 5,
    execute(message) {
        const fortunes = [
            "A beautiful, smart, and loving person will be coming into your life.",
            "A dubious friend may be an enemy in camouflage.",
            "A faithful friend is a strong defense.",
            "A fresh start will put you on your way.",
            "A golden egg of opportunity falls into your lap this month."
        ];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🥠 Fortune Cookie')
            .setDescription(fortunes[Math.floor(Math.random() * fortunes.length)]);

        message.channel.send({ embeds: [embed] });
    },
};
