const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'coinflip',
    description: 'Flip a coin',
    usage: ',coinflip',
    category: 'fun',
    cooldown: 3,
    execute(message) {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Coin Flip')
            .setDescription(`The coin landed on: **${result}**`)
            .setThumbnail(result === 'Heads' ? 
                'https://cdn.discordapp.com/attachments/123456789/heads.png' : 
                'https://cdn.discordapp.com/attachments/123456789/tails.png');

        message.channel.send({ embeds: [embed] });
    },
};