const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ascii',
    description: 'Convert text to ASCII art',
    usage: ',ascii <text>',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!args.length) return message.reply('Please provide some text to convert!');

        const text = args.join(' ');
        if (text.length > 20) return message.reply('Text must be 20 characters or less!');

        // Simple ASCII art conversion
        const asciiChars = {
            'a': '🄰', 'b': '🄱', 'c': '🄲', 'd': '🄳', 'e': '🄴',
            'f': '🄵', 'g': '🄶', 'h': '🄷', 'i': '🄸', 'j': '🄹',
            'k': '🄺', 'l': '🄻', 'm': '🄼', 'n': '🄽', 'o': '🄾',
            'p': '🄿', 'q': '🅀', 'r': '🅁', 's': '🅂', 't': '🅃',
            'u': '🅄', 'v': '🅅', 'w': '🅆', 'x': '🅇', 'y': '🅈',
            'z': '🅉', ' ': ' '
        };

        const asciiArt = text.toLowerCase().split('')
            .map(char => asciiChars[char] || char)
            .join('');

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('ASCII Art')
            .setDescription(asciiArt);

        message.channel.send({ embeds: [embed] });
    },
};