
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'word',
    description: 'Get a random word with definition',
    usage: ',word',
    category: 'fun',
    cooldown: 5,
    execute(message) {
        const words = [
            { word: "Serendipity", def: "Finding something good without looking for it" },
            { word: "Euphoria", def: "A feeling of intense excitement and happiness" },
            { word: "Mellifluous", def: "Sweet or musical; pleasant to hear" },
            { word: "Ethereal", def: "Extremely delicate and light" },
            { word: "Luminous", def: "Bright or shining, especially in the dark" }
        ];

        const randomWord = words[Math.floor(Math.random() * words.length)];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📚 Random Word')
            .addFields(
                { name: randomWord.word, value: randomWord.def }
            );

        message.channel.send({ embeds: [embed] });
    },
};
