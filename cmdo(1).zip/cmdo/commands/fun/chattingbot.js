const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'chattingbot',
    description: 'Enable or disable the chatting bot feature',
    usage: ',chattingbot <enable/disable>',
    category: 'fun',
    cooldown: 3,
    execute(message, args, client) {
        if (!client.chattingEnabled) {
            client.chattingEnabled = new Map();
        }
        if (!client.chattingTopics) {
            client.chattingTopics = new Map();
        }

        const channelId = message.channel.id;
        const action = args[0]?.toLowerCase();

        if (!action || (action !== 'enable' && action !== 'disable')) {
            const currentStatus = client.chattingEnabled.get(channelId) ? 'enabled' : 'disabled';
            const currentTopic = client.chattingTopics.get(channelId) || 'general chat';
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Chatting Bot')
                .setDescription('Enable or disable the chatting bot in this channel')
                .addFields(
                    { name: 'Current Status', value: currentStatus, inline: true },
                    { name: 'Current Topic', value: currentTopic, inline: true },
                    { name: 'Usage', value: '`,chattingbot enable` - Turn on chatting\n`,chattingbot disable` - Turn off chatting\n`,talkabout <topic>` - Set a topic for the bot to talk about' }
                )
                .setFooter({ text: `Requested by ${message.author.tag}` });

            return message.channel.send({ embeds: [embed] });
        }

        if (action === 'enable') {
            client.chattingEnabled.set(channelId, true);
            
            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('Chatting Bot Enabled')
                .setDescription('The chatting bot is now enabled in this channel! I\'ll respond to messages here.')
                .addFields(
                    { name: 'Tip', value: 'Use `,talkabout <topic>` to set what I should talk about!' }
                )
                .setFooter({ text: `Enabled by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } else if (action === 'disable') {
            client.chattingEnabled.set(channelId, false);
            client.chattingTopics.delete(channelId);
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Chatting Bot Disabled')
                .setDescription('The chatting bot is now disabled in this channel.')
                .setFooter({ text: `Disabled by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        }
    },
};
