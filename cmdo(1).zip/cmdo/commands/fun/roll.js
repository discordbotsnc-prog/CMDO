
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'roll',
    description: 'Roll multiple dice',
    usage: ',roll <number of dice>d<sides> (e.g., ,roll 2d6)',
    category: 'fun',
    cooldown: 3,
    execute(message, args) {
        if (!args[0]) return message.reply('Please specify dice (e.g., 2d6)');
        
        const [dice, sides] = args[0].toLowerCase().split('d').map(Number);
        
        if (isNaN(dice) || isNaN(sides) || dice > 10 || sides > 100) {
            return message.reply('Invalid format. Use: 2d6 (max 10 dice, 100 sides)');
        }

        const rolls = [];
        for (let i = 0; i < dice; i++) {
            rolls.push(Math.floor(Math.random() * sides) + 1);
        }

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🎲 Dice Roll')
            .addFields(
                { name: 'Rolls', value: rolls.join(', ') },
                { name: 'Total', value: rolls.reduce((a, b) => a + b, 0).toString() }
            );

        message.channel.send({ embeds: [embed] });
    },
};
