const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'poll',
    description: 'Create a poll with reactions',
    usage: ',poll <question>',
    category: 'fun',
    cooldown: 10,
    async execute(message, args) {
        if (!args.length) return message.reply('Please provide a question for the poll!');

        const question = args.join(' ');

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('📊 Poll')
            .setDescription(question)
            .setFooter({ text: `Created by ${message.author.tag}` })
            .setTimestamp();

        const poll = await message.channel.send({ embeds: [embed] });
        await poll.react('👍');
        await poll.react('👎');
        await poll.react('🤷');
    },
};