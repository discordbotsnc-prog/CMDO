const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'unwarn',
    description: 'Remove a warning from a user',
    usage: ',unwarn <user> [warning number]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ModerateMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        
        if (!message.client.warnings) message.client.warnings = new Map();
        const userWarnings = message.client.warnings.get(target.id) || [];

        if (userWarnings.length === 0) {
            return message.reply('This user has no warnings!');
        }

        const warningIndex = args[1] ? parseInt(args[1]) - 1 : userWarnings.length - 1;
        
        if (isNaN(warningIndex) || warningIndex < 0 || warningIndex >= userWarnings.length) {
            return message.reply('Invalid warning number!');
        }

        userWarnings.splice(warningIndex, 1);
        message.client.warnings.set(target.id, userWarnings);

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('Warning Removed')
            .setDescription(`Removed warning #${warningIndex + 1} from **${target.user.tag}**`)
            .addFields({ name: 'Remaining Warnings', value: userWarnings.length.toString() });

        message.channel.send({ embeds: [embed] });
    },
};
