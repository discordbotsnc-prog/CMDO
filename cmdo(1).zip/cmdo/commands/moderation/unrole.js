
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'unrole',
    description: 'Remove a role from a user',
    usage: ',unrole <user> <@role>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageRoles],
    cooldown: 5,
    async execute(message, args) {
        if (args.length < 2) return message.reply('Please specify a user and mention a role! Example: ,unrole @user @Role');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');

        const role = message.mentions.roles.first();
        if (!role) return message.reply('Please mention a role to remove! Example: ,unrole @user @Role');

        if (role.position >= message.member.roles.highest.position)
            return message.reply('You cannot manage this role as it is higher than or equal to your highest role!');

        if (!target.roles.cache.has(role.id)) {
            return message.reply(`**${target.user.tag}** doesn't have the role **${role.name}**!`);
        }

        try {
            await target.roles.remove(role);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Role Removed')
                .setDescription(`Removed role **${role.name}** from **${target.user.tag}**`)
                .setFooter({ text: `Action by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error removing the role! Make sure I have permission to manage this role.');
        }
    },
};
