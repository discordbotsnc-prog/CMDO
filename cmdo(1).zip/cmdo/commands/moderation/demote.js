
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'demote',
    description: 'Demote a user to the next lower role',
    usage: ',demote <user>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageRoles],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to demote!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply('I need the "Manage Roles" permission to demote users!');
        }

        // Get all roles sorted by position (highest to lowest)
        const roles = message.guild.roles.cache
            .sort((a, b) => b.position - a.position)
            .filter(role => 
                role.id !== message.guild.id && // Exclude @everyone
                !role.managed && // Exclude managed roles (bot roles)
                role.position < message.guild.members.me.roles.highest.position // Only roles below bot's highest role
            );

        // Get target's highest role
        const currentRole = target.roles.highest;

        // Find the role that's exactly one position below the current role
        const nextRole = roles.find(role => role.position === currentRole.position - 1);

        if (!nextRole) {
            return message.reply('No suitable lower role available to demote to!');
        }

        // Check if the user trying to demote has a higher role than both roles
        if (message.member.roles.highest.position <= currentRole.position) {
            return message.reply('You cannot demote someone with a role higher than or equal to your own highest role!');
        }

        try {
            await target.roles.add(nextRole);
            await target.roles.remove(currentRole);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Demoted')
                .setDescription(`**${target.user.tag}** has been demoted`)
                .addFields(
                    { name: 'From Role', value: currentRole.name },
                    { name: 'To Role', value: nextRole.name }
                )
                .setTimestamp();

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error trying to demote that user! Make sure I have the proper permissions and the role hierarchy is correct.');
        }
    },
};
