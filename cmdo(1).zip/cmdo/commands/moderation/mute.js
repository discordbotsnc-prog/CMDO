const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'mute',
    description: 'Mute a member in the server',
    usage: ',mute <user> [duration] [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ModerateMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to mute!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.moderatable) return message.reply('I cannot mute this user!');

        let duration = 5; // Default 5 minutes
        if (args[1]) {
            const parsedDuration = parseInt(args[1]);
            if (!isNaN(parsedDuration) && parsedDuration > 0 && parsedDuration <= 40320) { // Max 28 days
                duration = parsedDuration;
            } else {
                return message.reply('Please provide a valid duration between 1 and 40320 minutes (28 days)!');
            }
        }

        const reason = args.slice(2).join(' ') || 'No reason provided';

        try {
            // Send DM to user before timeout
            const dmEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`You've been muted in ${message.guild.name}`)
                .setDescription(`**Duration:** ${duration} minutes\n**Reason:** ${reason}`)
                .setFooter({ text: `Muted by ${message.author.tag}` })
                .setTimestamp();

            try {
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.log(`Could not send DM to ${target.user.tag}`);
            }

            // Convert minutes to milliseconds for the timeout
            const timeoutDuration = duration * 60 * 1000;

            // Apply the timeout
            await target.timeout(timeoutDuration, reason);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Muted')
                .setDescription(`**${target.user.tag}** has been muted for ${duration} minutes\nReason: ${reason}`);

            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error muting that user!');
        }
    },
};