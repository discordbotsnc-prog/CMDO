const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'purgeall',
    description: 'Delete all messages in the current channel',
    usage: ',purgeall',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageMessages],
    cooldown: 10,
    async execute(message, args) {
        // Delete the command message first
        await message.delete().catch(() => null);

        try {
            const statusMessage = await message.channel.send('Starting to delete all messages...');
            let messagesDeleted = 0;

            // Keep fetching and deleting messages until none are left
            while (true) {
                const messages = await message.channel.messages.fetch({ limit: 100 });
                if (messages.size === 0) break;

                await message.channel.bulkDelete(messages, true);
                messagesDeleted += messages.size;

                // Update status every 500 messages
                if (messagesDeleted % 500 === 0) {
                    await statusMessage.edit(`🗑️ Deleted ${messagesDeleted} messages so far...`);
                }
            }

            // Send final confirmation that auto-deletes after 5 seconds
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Channel Purged')
                .setDescription(`Successfully deleted ${messagesDeleted} messages`)
                .setFooter({ text: `Requested by ${message.author.tag}` });

            const finalMessage = await message.channel.send({ embeds: [embed] });
            setTimeout(() => finalMessage.delete().catch(() => null), 5000);

        } catch (error) {
            console.error(error);
            if (error.code === 50034) {
                message.channel.send('Cannot delete messages older than 14 days! Use another method for older messages.')
                    .then(msg => setTimeout(() => msg.delete().catch(() => null), 5000));
            } else {
                message.channel.send('There was an error trying to delete messages!')
                    .then(msg => setTimeout(() => msg.delete().catch(() => null), 5000));
            }
        }
    },
};