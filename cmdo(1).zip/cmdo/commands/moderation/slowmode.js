const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'slowmode',
    description: 'Set the slowmode of a channel',
    usage: ',slowmode <seconds>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageChannels],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify the number of seconds!');
        
        const seconds = parseInt(args[0]);
        if (isNaN(seconds)) return message.reply('Please provide a valid number!');
        if (seconds < 0 || seconds > 21600) return message.reply('Slowmode must be between 0 and 21600 seconds!');

        try {
            await message.channel.setRateLimitPerUser(seconds);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Slowmode Set')
                .setDescription(`Channel slowmode has been set to ${seconds} seconds`);
            
            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error setting the slowmode!');
        }
    },
};
