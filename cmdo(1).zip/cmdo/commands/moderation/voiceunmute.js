const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'voiceunmute',
    description: 'Unmute a member in voice channels',
    usage: ',voiceunmute <user>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.MuteMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to voice unmute!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.voice.channel) return message.reply('That user is not in a voice channel!');
        if (!target.moderatable) return message.reply('I cannot unmute this user!');

        try {
            await target.voice.setMute(false);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Voice Unmuted')
                .setDescription(`**${target.user.tag}** has been voice unmuted`);
            
            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error voice unmuting that user!');
        }
    },
};
