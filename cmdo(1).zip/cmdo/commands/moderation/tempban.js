const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'tempban',
    description: 'Temporarily ban a member from the server',
    usage: ',tempban <user> <duration s/m/h/d/w/mo/y> [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.BanMembers],
    cooldown: 5,
    async execute(message, args) {
        if (args.length < 2) return message.reply('Please provide a user and duration (e.g., 1h, 1d)!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.bannable) return message.reply('I cannot ban this user!');

        const duration = args[1].toLowerCase();
        let banTime = 0;
        const value = parseInt(duration);
        
        if (duration.endsWith('s')) banTime = value * 1000;                           // Seconds
        else if (duration.endsWith('m')) banTime = value * 60000;                     // Minutes
        else if (duration.endsWith('h')) banTime = value * 3600000;                   // Hours
        else if (duration.endsWith('d')) banTime = value * 86400000;                  // Days
        else if (duration.endsWith('w')) banTime = value * 604800000;                 // Weeks
        else if (duration.endsWith('mo')) banTime = value * 2592000000;              // Months
        else if (duration.endsWith('y')) banTime = value * 31536000000;              // Years
        else return message.reply('Please specify time with s/m/h/d/w/mo/y (e.g., 30s, 5m, 12h, 1d, 2w, 1mo, 1y)');

        if (isNaN(banTime) || banTime < 1000) {
            return message.reply('Duration must be at least 1 second!');
        }

        const reason = args.slice(2).join(' ') || 'No reason provided';

        try {
            // Send DM to user before banning
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('You Have Been Temporarily Banned')
                    .setDescription(`You have been banned from ${message.guild.name}`)
                    .addFields(
                        { name: 'Duration', value: duration },
                        { name: 'Reason', value: reason }
                    );
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                message.channel.send('Could not DM the user about their ban.');
            }

            await target.ban({ reason: `${reason} (Temporary: ${duration})` });
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Temporarily Banned')
                .setDescription(`**${target.user.tag}** has been banned for ${duration}\nReason: ${reason}`);
            
            message.channel.send({ embeds: [embed] });

            // Store unban time in memory
            const unbanTime = Date.now() + banTime;
            
            // Check every hour if ban should be lifted
            const checkInterval = setInterval(async () => {
                if (Date.now() >= unbanTime) {
                    clearInterval(checkInterval);
                    try {
                        await message.guild.members.unban(target.id, 'Temporary ban expired');
                        const unbanEmbed = new EmbedBuilder()
                            .setColor('#FF0000')
                            .setTitle('Member Unbanned')
                            .setDescription(`**${target.user.tag}**'s temporary ban has expired`);
                        
                        message.channel.send({ embeds: [unbanEmbed] });
                    } catch (error) {
                        console.error('Error unbanning user:', error);
                    }
                }
            }, 3600000); // Check every hour
        } catch (error) {
            console.error(error);
            message.reply('There was an error banning that user!');
        }
    },
};
