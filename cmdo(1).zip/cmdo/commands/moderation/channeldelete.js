const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'channeldelete',
    description: 'Delete a specified channel',
    usage: ',channeldelete <channel>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageChannels],
    cooldown: 10,
    async execute(message, args) {
        // Check if user has permission
        if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.reply({
                content: '❌ You do not have permission to delete channels! You need the "Manage Channels" permission.',
                ephemeral: true
            });
        }

        // Check if bot has necessary permissions
        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return message.reply({
                content: '❌ I don\'t have permission to delete channels! Please give me the "Manage Channels" permission.',
                ephemeral: true
            });
        }

        if (!args.length) {
            return message.reply('Please specify a channel to delete!');
        }

        // Get the target channel
        const targetChannel = message.mentions.channels.first() || 
            message.guild.channels.cache.find(ch => 
                ch.name.toLowerCase() === args.join('-').toLowerCase()
            );

        if (!targetChannel) {
            return message.reply('Could not find that channel! Please mention the channel or provide its exact name.');
        }

        // Don't allow deleting the channel where command was used
        if (targetChannel.id === message.channel.id) {
            return message.reply('You cannot delete the channel you\'re currently in!');
        }

        try {
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Channel Deleted')
                .setDescription(`Channel **${targetChannel.name}** has been deleted`)
                .addFields(
                    { name: 'Deleted By', value: message.author.tag },
                    { name: 'Channel Type', value: targetChannel.type === 0 ? 'Text Channel' : 'Other' }
                )
                .setTimestamp();

            // Send confirmation before deleting
            await message.channel.send({ embeds: [embed] });

            // Delete the channel
            await targetChannel.delete(`Deleted by ${message.author.tag}`);
        } catch (error) {
            console.error('Channel deletion error:', error);
            message.reply('There was an error trying to delete that channel! Please check my permissions and try again.');
        }
    },
};