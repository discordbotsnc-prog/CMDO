const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'voicemute',
    description: 'Mute a member in voice channels',
    usage: ',voicemute <user> [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.MuteMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to voice mute!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.voice.channel) return message.reply('That user is not in a voice channel!');
        if (!target.moderatable) return message.reply('I cannot mute this user!');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            await target.voice.setMute(true, reason);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Voice Muted')
                .setDescription(`**${target.user.tag}** has been voice muted\nReason: ${reason}`);

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error voice muting that user!');
        }
    },
};