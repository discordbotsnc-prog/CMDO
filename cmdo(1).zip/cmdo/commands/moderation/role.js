
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'role',
    description: 'Add or remove a role from a user',
    usage: ',role <user> <@role>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageRoles],
    cooldown: 5,
    async execute(message, args) {
        if (args.length < 2) return message.reply('Please specify a user and mention a role! Example: ,role @user @Role');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');

        const role = message.mentions.roles.first();
        if (!role) return message.reply('Please mention a role to add/remove! Example: ,role @user @Role');

        if (role.position >= message.member.roles.highest.position)
            return message.reply('You cannot manage this role as it is higher than or equal to your highest role!');

        try {
            if (target.roles.cache.has(role.id)) {
                await target.roles.remove(role);
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Role Removed')
                    .setDescription(`Removed role **${role.name}** from **${target.user.tag}**`)
                    .setFooter({ text: `Action by ${message.author.tag}` });

                message.channel.send({ embeds: [embed] });
            } else {
                await target.roles.add(role);
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Role Added')
                    .setDescription(`Added role **${role.name}** to **${target.user.tag}**`)
                    .setFooter({ text: `Action by ${message.author.tag}` });

                message.channel.send({ embeds: [embed] });
            }
        } catch (error) {
            console.error(error);
            message.reply('There was an error managing the role! Make sure I have permission to manage this role.');
        }
    },
};
