const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nickname')
        .setDescription('Change a user\'s nickname')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('The user to change nickname')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('nickname')
                .setDescription('The new nickname (leave empty to reset)'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),
    cooldown: 5,
    async execute(interaction) {
        const target = interaction.options.getMember('target');
        const newNickname = interaction.options.getString('nickname') || null; // null resets the nickname

        if (!target) {
            return interaction.reply({ content: 'Could not find that user!', ephemeral: true });
        }

        if (target.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply({ content: 'You cannot change this user\'s nickname!', ephemeral: true });
        }

        try {
            await target.setNickname(newNickname);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Nickname Changed')
                .setDescription(`**${target.user.tag}**'s nickname has been ${newNickname ? 'changed to: ' + newNickname : 'reset'}`);

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ 
                content: 'There was an error changing the nickname!', 
                ephemeral: true 
            });
        }
    },
};