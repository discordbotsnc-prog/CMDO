const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('filter')
        .setDescription('Manage word filter')
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List all filtered words'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add a word to the filter')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('The word to filter')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove a word from the filter')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('The word to remove')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    cooldown: 5,
    async execute(interaction) {
        if (!interaction.client.filters) interaction.client.filters = new Set();

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'list') {
            const filterList = [...interaction.client.filters].join(', ') || 'No filtered words';
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Filtered Words')
                .setDescription(filterList);

            await interaction.reply({ embeds: [embed], ephemeral: true });
            return;
        }

        const word = interaction.options.getString('word').toLowerCase();

        if (subcommand === 'add') {
            interaction.client.filters.add(word);
            await interaction.reply({ 
                content: `Added "${word}" to the filter list.`,
                ephemeral: true 
            });
        } else if (subcommand === 'remove') {
            if (interaction.client.filters.has(word)) {
                interaction.client.filters.delete(word);
                await interaction.reply({ 
                    content: `Removed "${word}" from the filter list.`,
                    ephemeral: true 
                });
            } else {
                await interaction.reply({ 
                    content: 'That word is not in the filter list!',
                    ephemeral: true 
                });
            }
        }
    },
};