const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'lock',
    description: 'Lock a channel',
    usage: ',lock [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageChannels],
    cooldown: 5,
    async execute(message, args) {
        const reason = args.join(' ') || 'No reason provided';

        try {
            // Check if channel is already locked
            const currentPerms = message.channel.permissionsFor(message.guild.roles.everyone);
            if (!currentPerms.has(PermissionFlagsBits.SendMessages)) {
                return message.reply('This channel is already locked!');
            }

            await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: false
            });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Channel Locked')
                .setDescription(`This channel has been locked\nReason: ${reason}`)
                .setFooter({ text: `Locked by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error locking the channel!');
        }
    },
};