const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'tempchannel',
    description: 'Create a temporary channel that deletes itself after specified time',
    usage: '!tempchannel <name> <duration in minutes>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageChannels],
    cooldown: 10,
    async execute(message, args) {
        if (args.length < 2) {
            return message.reply('Please provide a channel name and duration (in minutes)!');
        }

        const channelName = args[0];
        const duration = parseInt(args[1]);

        if (isNaN(duration) || duration < 1 || duration > 1440) {
            return message.reply('Duration must be between 1 and 1440 minutes (24 hours)!');
        }

        try {
            const tempChannel = await message.guild.channels.create({
                name: channelName,
                type: 0, // Text channel
                reason: `Temporary channel created by ${message.author.tag}`
            });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Temporary Channel Created')
                .setDescription(`Channel ${tempChannel} will be deleted in ${duration} minutes`)
                .addFields(
                    { name: 'Created By', value: message.author.tag },
                    { name: 'Duration', value: `${duration} minutes` }
                );

            message.channel.send({ embeds: [embed] });

            // Delete the channel after the specified duration
            setTimeout(async () => {
                try {
                    await tempChannel.delete('Temporary channel duration expired');
                } catch (error) {
                    console.error('Error deleting temporary channel:', error);
                }
            }, duration * 60000);
        } catch (error) {
            console.error(error);
            message.reply('There was an error creating the temporary channel!');
        }
    },
};
