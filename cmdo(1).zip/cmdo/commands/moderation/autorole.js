const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'autorole',
    description: 'View, set or configure auto-role settings for new members',
    usage: ',autorole <view/set/join> [role]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageRoles],
    cooldown: 5,
    async execute(message, args, client) {
        try {
            // Check if user has permission
            if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return message.reply({
                    content: '❌ You need the "Manage Roles" permission to use this command!',
                    ephemeral: true
                });
            }

            // Check if bot has necessary permissions
            if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return message.reply({
                    content: '❌ I need the "Manage Roles" permission to manage auto-roles!',
                    ephemeral: true
                });
            }

            if (!args.length) {
                return message.reply('Please specify an action: view, set, or join');
            }

            const action = args[0].toLowerCase();
            const currentRoleId = client.autoRoles.get('DEFAULT_ROLE_ID');

            // View current auto-role settings
            if (action === 'view') {
                if (!currentRoleId) {
                    return message.reply('No auto-role is currently configured.');
                }

                const role = message.guild.roles.cache.get(currentRoleId);
                if (!role) {
                    return message.reply('The configured auto-role no longer exists in this server.');
                }

                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Auto-Role Settings')
                    .addFields(
                        { name: 'Role Name', value: role.name },
                        { name: 'Role ID', value: role.id },
                        { name: 'Role Color', value: role.hexColor },
                        { name: 'Role Position', value: role.position.toString() },
                        { name: 'Member Count', value: role.members.size.toString() }
                    )
                    .setFooter({ text: 'This role is automatically assigned to new members' });

                return message.channel.send({ embeds: [embed] });
            }

            // Set or join auto-role
            if (action === 'set' || action === 'join') {
                if (!args[1]) {
                    return message.reply('Please mention a role or provide a role ID!');
                }

                const newRole = message.mentions.roles.first() || 
                    message.guild.roles.cache.get(args[1]);

                if (!newRole) {
                    return message.reply('Please mention a valid role or provide a valid role ID!');
                }

                // Check role hierarchy
                const botRole = message.guild.members.me.roles.highest;
                if (newRole.position >= botRole.position) {
                    return message.reply(
                        `❌ I cannot manage the role "${newRole.name}" because it's positioned higher than or equal to my highest role (${botRole.name}).\n` +
                        'To fix this, move my role above the target role in the server settings.'
                    );
                }

                // Update the auto-role ID
                client.autoRoles.set('DEFAULT_ROLE_ID', newRole.id);

                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Auto-Role Updated')
                    .setDescription(`New members will now automatically receive the **${newRole.name}** role.\nRole ID: ${newRole.id}`)
                    .addFields(
                        { name: 'Role Color', value: newRole.hexColor },
                        { name: 'Role Position', value: newRole.position.toString() }
                    )
                    .setFooter({ text: `Set by ${message.author.tag}` });

                await message.channel.send({ embeds: [embed] });

                // Handle join action
                if (action === 'join') {
                    try {
                        if (message.member.roles.cache.has(newRole.id)) {
                            return message.reply(`You already have the **${newRole.name}** role!`);
                        }

                        await message.member.roles.add(newRole);
                        const joinEmbed = new EmbedBuilder()
                            .setColor('#FF0000')
                            .setTitle('Role Joined')
                            .setDescription(`You have been given the **${newRole.name}** role!`);

                        await message.channel.send({ embeds: [joinEmbed] });
                    } catch (error) {
                        console.error('Error adding role to member:', error);
                        message.reply(`Error assigning role: ${error.message}`);
                    }
                }
            } else {
                message.reply('Invalid action! Use: view, set, or join');
            }
        } catch (error) {
            console.error('Autorole command error:', error);
            message.reply(`An error occurred: ${error.message}`);
        }
    },
};