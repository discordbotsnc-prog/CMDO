const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verification')
        .setDescription('Manage server verification settings')
        .addSubcommand(subcommand =>
            subcommand
                .setName('view')
                .setDescription('View current verification settings'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set verification level')
                .addStringOption(option =>
                    option.setName('level')
                        .setDescription('The verification level to set')
                        .setRequired(true)
                        .addChoices(
                            { name: 'None', value: 'NONE' },
                            { name: 'Low', value: 'LOW' },
                            { name: 'Medium', value: 'MEDIUM' },
                            { name: 'High', value: 'HIGH' },
                            { name: 'Highest', value: 'VERY_HIGH' }
                        )))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    cooldown: 10,
    async execute(interaction) {
        const guild = interaction.guild;
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'view') {
            const levels = {
                NONE: 'None - unrestricted',
                LOW: 'Low - must have verified email',
                MEDIUM: 'Medium - must be registered for 5 minutes',
                HIGH: 'High - must be a member for 10 minutes',
                VERY_HIGH: 'Highest - must have verified phone'
            };

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Server Verification Settings')
                .addFields(
                    { name: 'Current Level', value: levels[guild.verificationLevel] || 'Unknown' },
                    { name: 'Available Levels', value: Object.entries(levels).map(([key, value]) => 
                        `• ${key.toLowerCase()}: ${value}`).join('\n')
                    }
                );

            await interaction.reply({ embeds: [embed] });
        } else if (subcommand === 'set') {
            const level = interaction.options.getString('level');

            try {
                await guild.setVerificationLevel(level);
                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('Verification Level Updated')
                    .setDescription(`Server verification level has been set to: ${level}`);

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error(error);
                await interaction.reply({ 
                    content: 'There was an error updating the verification level!', 
                    ephemeral: true 
                });
            }
        }
    },
};