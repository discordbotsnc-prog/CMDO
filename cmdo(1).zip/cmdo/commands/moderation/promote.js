const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'promote',
    description: 'Promote a user to the next higher role',
    usage: ',promote <user>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.Administrator],
    cooldown: 5,
    async execute(message, args) {
        // Check if user is owner
        if (!message.guild.ownerId === message.author.id) {
            return message.reply('Only the server owner can use the promote command!');
        }

        if (!args[0]) return message.reply('Please specify a user to promote!');

        // Get target user
        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);
        
        if (!target) return message.reply('Could not find that user!');
        
        if (target.id === message.author.id) {
            return message.reply('You cannot promote yourself!');
        }

        if (!target) return message.reply('Could not find that user!');

        if (!message.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return message.reply('I need the "Manage Roles" permission to promote users!');
        }

        // Get all roles sorted by position (lowest to highest)
        const roles = message.guild.roles.cache
            .sort((a, b) => a.position - b.position)
            .filter(role => 
                role.id !== message.guild.id && // Exclude @everyone
                !role.managed && // Exclude managed roles (bot roles)
                role.position < message.guild.members.me.roles.highest.position // Only roles below bot's highest role
            );

        // Get target's highest role
        const currentRole = target.roles.highest;

        // Find the role that's exactly one position above the current role
        const nextRole = roles.find(role => role.position === currentRole.position + 1);

        if (!nextRole) {
            return message.reply('No suitable higher role available to promote to!');
        }

        // Check if the user trying to promote has a higher role than the role they're trying to give
        if (message.member.roles.highest.position <= nextRole.position) {
            return message.reply('You cannot promote to a role higher than or equal to your own highest role!');
        }

        try {
            await target.roles.add(nextRole);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Promoted')
                .setDescription(`**${target.user.tag}** has been promoted`)
                .addFields(
                    { name: 'From Role', value: currentRole.name },
                    { name: 'To Role', value: nextRole.name }
                )
                .setTimestamp();

            message.channel.send({ embeds: [embed] });

            // Send DM to promoted user
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('🎉 Promotion Notice')
                    .setDescription(`You have been promoted in ${message.guild.name}!`)
                    .addFields(
                        { name: 'From Role', value: currentRole.name },
                        { name: 'To Role', value: nextRole.name }
                    )
                    .setTimestamp();
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                message.channel.send('Could not DM the user about their promotion.');
            }
        } catch (error) {
            console.error(error);
            message.reply('There was an error trying to promote that user! Make sure I have the proper permissions and the role hierarchy is correct.');
        }
    },
};