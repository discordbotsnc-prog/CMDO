const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'logs',
    description: 'Enable or disable server event logging in a specific channel',
    usage: ',logs <enable/disable> [channel name]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageGuild],
    cooldown: 5,
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Please specify whether to enable or disable logging! Example: ,logs enable #bot-logs');
        }

        const action = args[0].toLowerCase();
        if (!['enable', 'disable'].includes(action)) {
            return message.reply('Invalid action! Use: enable or disable');
        }

        // Initialize logs storage if it doesn't exist
        const fs = require('fs');
        const path = require('path');
        const logsPath = path.join(__dirname, '../../data/logs.json');

        // Ensure data directory exists
        if (!fs.existsSync(path.join(__dirname, '../../data'))) {
            fs.mkdirSync(path.join(__dirname, '../../data'));
        }

        // Load or create logs data
        let logsData;
        try {
            logsData = JSON.parse(fs.readFileSync(logsPath));
        } catch {
            logsData = { channels: {} };
        }

        if (action === 'enable') {
            const channel = message.mentions.channels.first();
            if (!channel) {
                return message.reply('Please mention a channel! Example: ,logs enable #bot-logs');
            }

            logsData.channels[message.guild.id] = channel.id;
            fs.writeFileSync(logsPath, JSON.stringify(logsData, null, 2));
            message.client.logsChannel.set(message.guild.id, channel.id);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('📝 Server Logging Enabled')
                .setDescription(`Server events will now be logged in ${channel}`)
                .addFields(
                    { name: 'Logged Events', value: '• Channel creations/deletions\n• Role changes\n• Member joins/leaves\n• Server setting changes\n• Moderation actions' },
                    { name: 'Channel', value: channel.name },
                    { name: 'Enabled by', value: message.author.tag }
                )
                .setTimestamp();

            message.channel.send({ embeds: [embed] });

            // Send test log
            const testEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🟢 Server Logging Started')
                .setDescription('Server event logging has been enabled in this channel')
                .addFields(
                    { name: 'Server Events Tracked', value: '• Channel modifications\n• Role changes\n• Member changes\n• Server settings\n• Moderation actions' }
                )
                .setFooter({ text: `Configured by ${message.author.tag}` })
                .setTimestamp();

            channel.send({ embeds: [testEmbed] });
        } else if (action === 'disable') {
            if (logsData.channels[message.guild.id]) {
                const oldChannelId = logsData.channels[message.guild.id];
                const oldChannel = message.guild.channels.cache.get(oldChannelId);

                delete logsData.channels[message.guild.id];
                fs.writeFileSync(logsPath, JSON.stringify(logsData, null, 2));
                message.client.logsChannel.delete(message.guild.id);

                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('📝 Server Logging Disabled')
                    .setDescription(`Server event logging has been disabled${oldChannel ? ` in ${oldChannel}` : ''}`)
                    .addFields(
                        { name: 'Previous Channel', value: oldChannel ? oldChannel.name : 'Unknown' },
                        { name: 'Disabled by', value: message.author.tag }
                    )
                    .setTimestamp();

                message.channel.send({ embeds: [embed] });

                if (oldChannel) {
                    const finalLog = new EmbedBuilder()
                        .setColor('#FF0000')
                        .setTitle('🔴 Server Logging Ended')
                        .setDescription('Server event logging has been disabled')
                        .addFields({ name: 'Disabled by', value: message.author.tag })
                        .setTimestamp();

                    oldChannel.send({ embeds: [finalLog] });
                }
            } else {
                message.reply('Logging was not enabled in this server!');
            }
        }
    },
};