
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'resetmsgs',
    description: 'Reset message count for a user',
    usage: ',resetmsgs [@user]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.Administrator],
    cooldown: 5,
    async execute(message, args) {
        try {
            const target = message.mentions.users.first() || message.author;
            
            // Reset messages for this server
            const messagesPath = path.join(__dirname, '../../data/messages.json');
            let messageData = { addedMessages: {} };
            
            if (fs.existsSync(messagesPath)) {
                messageData = JSON.parse(fs.readFileSync(messagesPath));
            }

            const guildId = message.guild.id;
            const userId = target.id;

            // Ensure the guild exists in the data
            if (!messageData.addedMessages[guildId]) {
                messageData.addedMessages[guildId] = {};
            }

            // Set the user's messages to 0
            messageData.addedMessages[guildId][userId] = 0;

            // Save to file
            fs.writeFileSync(messagesPath, JSON.stringify(messageData, null, 2));
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Messages Reset')
                .setDescription(`Reset message count for **${target.tag}** to 0`)
                .setFooter({ text: `Reset by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error resetting messages:', error);
            message.reply('There was an error resetting the messages.');
        }
    },
};
