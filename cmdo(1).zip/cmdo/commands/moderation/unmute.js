const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'unmute',
    description: 'Unmute a member in the server',
    usage: ',unmute <user>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ModerateMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to unmute!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.moderatable) return message.reply('I cannot unmute this user!');

        try {
            await target.timeout(null);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Unmuted')
                .setDescription(`**${target.user.tag}** has been unmuted`);
            
            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error unmuting that user!');
        }
    },
};
