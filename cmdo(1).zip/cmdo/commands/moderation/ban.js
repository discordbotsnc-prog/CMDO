const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Ban a member from the server',
    usage: ',ban <user> [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.BanMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify a user to ban!');

        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => null);

        if (!target) return message.reply('Could not find that user!');
        if (!target.bannable) return message.reply('I cannot ban this user!');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            // Send DM to user before banning
            const dmEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle(`You've been banned from ${message.guild.name}`)
                .setDescription(`**Reason:** ${reason}`)
                .setFooter({ text: `Banned by ${message.author.tag}` })
                .setTimestamp();

            try {
                await target.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.log(`Could not send DM to ${target.user.tag}`);
            }

            // Proceed with ban
            await target.ban({ reason });
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Banned')
                .setDescription(`**${target.user.tag}** has been banned\nReason: ${reason}`);

            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error banning that user!');
        }
    },
};