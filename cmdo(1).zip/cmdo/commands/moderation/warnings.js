const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'warnings',
    description: 'View warnings for a user',
    usage: ',warnings [user]',
    category: 'moderation',
    cooldown: 5,
    async execute(message, args) {
        const target = message.mentions.members.first() || 
            await message.guild.members.fetch(args[0]).catch(() => message.member) ||
            message.member;

        if (!message.client.warnings) message.client.warnings = new Map();
        const userWarnings = message.client.warnings.get(target.id) || [];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(`Warnings for ${target.user.tag}`)
            .setDescription(userWarnings.length === 0 ? 
                'This user has no warnings!' : 
                userWarnings.map((warning, index) => {
                    const moderator = message.guild.members.cache.get(warning.moderator);
                    return `**${index + 1}.** ${warning.reason}\nBy: ${moderator ? moderator.user.tag : 'Unknown'}\nDate: ${new Date(warning.timestamp).toLocaleDateString()}`;
                }).join('\n\n'));

        message.channel.send({ embeds: [embed] });
    },
};
