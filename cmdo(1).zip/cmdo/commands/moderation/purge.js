const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'purge',
    description: 'Delete a specified number of messages',
    usage: ',purge <number>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageMessages],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please specify the number of messages to delete!');

        const amount = parseInt(args[0]);
        if (isNaN(amount)) return message.reply('Please provide a valid number!');
        if (amount <= 0 || amount > 100) return message.reply('Please provide a number between 1 and 100!');

        try {
            const messages = await message.channel.messages.fetch({ limit: amount });
            const deletedMessages = await message.channel.bulkDelete(messages, true);

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🗑️ Messages Purged')
                .setDescription(`Successfully deleted ${deletedMessages.size} messages`)
                .setFooter({ text: `Requested by ${message.author.tag}` });

            const reply = await message.channel.send({ embeds: [embed] });

            // Delete the confirmation message after 5 seconds
            setTimeout(() => {
                reply.delete().catch(() => {});
            }, 5000);
        } catch (error) {
            console.error(error);
            if (error.code === 50034) {
                message.reply('Cannot delete messages older than 14 days!');
            } else {
                message.reply('There was an error trying to delete messages!');
            }
        }
    },
};