const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'unlock',
    description: 'Unlock a channel',
    usage: ',unlock',
    category: 'moderation',
    permissions: [PermissionFlagsBits.ManageChannels],
    cooldown: 5,
    async execute(message) {
        try {
            await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: null
            });

            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Channel Unlocked')
                .setDescription('This channel has been unlocked')
                .setFooter({ text: `Unlocked by ${message.author.tag}` });

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            message.reply('There was an error unlocking the channel!');
        }
    },
};
