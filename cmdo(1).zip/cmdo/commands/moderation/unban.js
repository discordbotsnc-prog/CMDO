
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'unban',
    description: 'Unban a user from the server',
    usage: ',unban <user ID>',
    category: 'moderation',
    permissions: [PermissionFlagsBits.BanMembers],
    cooldown: 5,
    async execute(message, args) {
        if (!args[0]) return message.reply('Please provide a user ID or mention to unban! Usage: ,unban <user ID/@user>');
        
        // Extract user ID from mention or use direct ID
        const userId = args[0].replace(/[<@!>]/g, '');
        
        if (isNaN(userId)) return message.reply('Please provide a valid user ID or mention!');

        try {
            const banList = await message.guild.bans.fetch();
            const bannedUser = banList.find(ban => ban.user.id === userId);

            if (!bannedUser) {
                return message.reply('This user ID is not banned!');
            }

            await message.guild.members.unban(userId);
            
            // Create and send server embed
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('Member Unbanned')
                .setDescription(`**${bannedUser.user.tag}** has been unbanned`)
                .setFooter({ text: `Unbanned by ${message.author.tag}` })
                .setTimestamp();
            
            message.channel.send({ embeds: [embed] });

            // Try to DM the unbanned user
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle(`You've been unbanned from ${message.guild.name}`)
                    .setDescription(`You can now rejoin the server.`)
                    .setFooter({ text: `Unbanned by ${message.author.tag}` })
                    .setTimestamp();

                await bannedUser.user.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.log(`Could not send DM to ${bannedUser.user.tag}`);
            }
        } catch (error) {
            console.error(error);
            message.reply('There was an error unbanning that user! Make sure the ID is correct.');
        }
    },
};
