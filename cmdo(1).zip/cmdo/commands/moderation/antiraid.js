
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'antiraid',
    description: 'Toggle anti-raid mode for the server',
    usage: ',antiraid <on/off> [reason]',
    category: 'moderation',
    permissions: [PermissionFlagsBits.Administrator],
    cooldown: 10,
    async execute(message, args) {
        try {
            if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return message.reply('You need Administrator permission to use this command!');
            }

            if (!args[0]) {
                return message.reply('Please specify whether to turn anti-raid mode on or off!');
            }

            const action = args[0].toLowerCase();
            if (!['on', 'off'].includes(action)) {
                return message.reply('Please use "on" or "off"!');
            }

            const reason = args.slice(1).join(' ') || 'No reason provided';
            const guild = message.guild;

            // Check bot permissions
            const requiredPermissions = [
                PermissionFlagsBits.ManageRoles,
                PermissionFlagsBits.ManageChannels,
                PermissionFlagsBits.ManageGuild
            ];

            if (!guild.members.me.permissions.has(requiredPermissions)) {
                return message.reply('I need Manage Roles, Manage Channels, and Manage Guild permissions to use anti-raid mode!');
            }

            if (action === 'on') {
                await guild.setVerificationLevel(3); // 3 represents HIGH verification level
                await guild.setExplicitContentFilter('ALL');

                // Get or create member role
                let memberRole = guild.roles.cache.find(r => r.name === 'Member');
                if (!memberRole) {
                    memberRole = await guild.roles.create({
                        name: 'Member',
                        reason: 'Anti-raid setup'
                    });
                }

                // Restrict member role permissions
                await memberRole.setPermissions([
                    PermissionFlagsBits.ViewChannel,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.ReadMessageHistory
                ]);

                const embed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('🛡️ Anti-Raid Mode Enabled')
                    .setDescription('Server security has been increased')
                    .addFields(
                        { name: 'Actions Taken', value: '• Verification level set to HIGH\n• Content filter strengthened\n• Member permissions restricted' },
                        { name: 'Reason', value: reason }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Enabled by ${message.author.tag}` });

                return message.channel.send({ embeds: [embed] });
            } else {
                await guild.setVerificationLevel(1); // 1 represents LOW verification level
                await guild.setExplicitContentFilter('DISABLED');

                // Find and restore member role permissions
                const memberRole = guild.roles.cache.find(r => r.name === 'Member');
                if (memberRole) {
                    await memberRole.setPermissions([
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                        PermissionFlagsBits.AddReactions,
                        PermissionFlagsBits.Connect,
                        PermissionFlagsBits.Speak
                    ]);
                }

                const embed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('🛡️ Anti-Raid Mode Disabled')
                    .setDescription('Server security has been restored to normal')
                    .addFields(
                        { name: 'Actions Taken', value: '• Verification level restored\n• Content filter restored\n• Member permissions restored' },
                        { name: 'Reason', value: reason }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Disabled by ${message.author.tag}` });

                return message.channel.send({ embeds: [embed] });
            }
        } catch (error) {
            console.error('Anti-raid error:', error);
            return message.reply('An error occurred while toggling anti-raid mode. Please check my permissions and try again.');
        }
    },
};
